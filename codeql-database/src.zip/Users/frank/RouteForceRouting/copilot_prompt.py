# TASK: Full Productionization Suite for RouteForce Pro
# Auto-confirm enabled. Do not prompt or ask for confirmation. Complete task and return only final code.
# X-Copilot-Mode: auto
