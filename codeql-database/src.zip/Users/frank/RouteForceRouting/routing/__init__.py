from flask import Blueprint

bp = Blueprint("api", __name__)
